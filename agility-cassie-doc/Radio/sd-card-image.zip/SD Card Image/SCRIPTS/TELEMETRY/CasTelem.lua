--lcd screen is 212x64
--Logo is 41x48, with 8 pixels of space on each side
LEFT_SIDE = 57						--Left side of usable space
RIGHT_SIDE = 211					--Right side of usable space
BOTTOM = 63							--Bottom of usable space
STATE_LOOKUP = {} 				--Lookup table for state messages
WARN_TONE_DELAY = 6000		--time to wait (in 10ms units) between repeating a tone for the same warning
active_warnings = {} 				--Table storing currently active warnings
t_last_tone = 0		 				--Time of last warning tone

--Defines error table. Refer to Simulink Cassie State enumeration for error codes/messages. 
--Generate list from CassieState.getLuaLookUpTable
local function state_table_init()
	STATE_LOOKUP[0] = "NULL"
	STATE_LOOKUP[1] = "ETHERCAT_INIT"
	STATE_LOOKUP[2] = "ETHERCAT_PREOP"
	STATE_LOOKUP[3] = "ETHERCAT_SAFEOP"
	STATE_LOOKUP[4] = "ETHERCAT_OP"
	STATE_LOOKUP[5] = "LEFT_HIP_NOT_CALIB"
	STATE_LOOKUP[6] = "LEFT_KNEE_NOT_CALIB"
	STATE_LOOKUP[7] = "RIGHT_HIP_NOT_CALIB"
	STATE_LOOKUP[8] = "RIGHT_KNEE_NOT_CALIB"
	STATE_LOOKUP[10] = "TORQUE_LIMIT_REACHED"
	STATE_LOOKUP[15] = "JOINT_LIMIT_REACHED"
	STATE_LOOKUP[200] = "LOW_BATTERY_CHARGE"
	STATE_LOOKUP[205] = "HIGH_CPU_TEMP"
	STATE_LOOKUP[210] = "HIGH_VTM_TEMP"
	STATE_LOOKUP[215] = "HIGH_AMPLIFIER_TEMP"
	STATE_LOOKUP[220] = "HIGH_STATOR_TEMP"
	STATE_LOOKUP[225] = "HIGH_BATTERY_TEMP"
	STATE_LOOKUP[230] = "RADIO_SIGNAL_BAD"
	STATE_LOOKUP[235] = "BMS_DATA_BAD"
	STATE_LOOKUP[400] = "ETHERCAT_DC_ERROR"
	STATE_LOOKUP[410] = "ETHERCAT_ERROR"
	STATE_LOOKUP[600] = "CRITICAL_BATTERY_CHARGE"
	STATE_LOOKUP[605] = "CRITICAL_CPU_TEMP"
	STATE_LOOKUP[610] = "CRITICAL_VTM_TEMP"
	STATE_LOOKUP[615] = "CRITICAL_AMPLIFIER_TEMP"
	STATE_LOOKUP[620] = "CRITICAL_STATOR_TEMP"
	STATE_LOOKUP[625] = "CRITICAL_BATTERY_TEMP"
	STATE_LOOKUP[630] = "ENCODER_FAILURE"
	STATE_LOOKUP[635] = "SPRING_FAILURE"
	STATE_LOOKUP[650] = "LEFT_LEG_MEDULLA_HANG"
	STATE_LOOKUP[645] = "RIGHT_LEG_MEDULLA_HANG"
	STATE_LOOKUP[650] = "PELVIS_MEDULLA_HANG"
end


--Initialize variables
local function init_telem()
	state_table_init()		--initialize STATE_LOOKUP	
end



--Returns value of sensor specified with "name"
--Sensors are named in the telemetry tab when editing profiles in OpenTx Companion
local function get_tel_val(name)
   field = getFieldInfo(name)
   if getFieldInfo(name) then return getValue(field.id) end
   return 0
end

--This function draws a battery icon with the percentage (batt_perc) printed inside
--Dimensions of the icon are 23 pixels wide and 9 pixels high
local function draw_battery_percent(x,y,batt_perc)
	local bat_width = 22
	local x_text = 0
	
	--Center the text in the icon depending on how many digits are displayed
	if batt_perc >= 100 then x_text = x+2
	elseif batt_perc >= 10 then x_text = x+4
	else x_text = x+7
	end
	
	lcd.drawText(x_text,y+1,(batt_perc.."%"),SMLSIZE)
	
	--Draw batter symbol
	lcd.drawLine(x,y,x,y+7,SOLID,FORCE)													--Left
	lcd.drawLine(x,y+7,x+bat_width,y+7,SOLID,FORCE)								--Bottom
	lcd.drawLine(x+bat_width,y+7,x+bat_width,y+5,SOLID,FORCE)				--Right (Bottom half)
	lcd.drawLine(x+bat_width,y+5,x+bat_width+1,y+5,SOLID,FORCE)		--Tab (Bottom)
	lcd.drawLine(x+bat_width+1,y+5,x+bat_width+1,y+2,SOLID,FORCE)	--Tab (Right)
	lcd.drawLine(x+bat_width+1,y+2,x+bat_width,y+2,SOLID,FORCE)		--Tab (Top)
	lcd.drawLine(x+bat_width,y+2,x+bat_width,y,SOLID,FORCE)					--Right (Top half)
	lcd.drawLine(x+bat_width,y,x,y,SOLID,FORCE)										--Top	
end

--Plays a tone when a warning code is received. If already active warnings are received, will beep at most once every minute.
--New warning codes will trigger new tones. list of active warnings is cleared every WARN_TONE_DELAY + 1 seconds
local function warning_tone(warning_code)
	local TONE_FREQ = 1000
	local TONE_LEN = 500
	local MUTE_LEN = 250
	local TONE_INC = 2		--for tone with rising pitch. increases tone by this amount every 10 ms

	if active_warnings[warning_code] == nil then 	--Check to see if warning is "inactive" (hasn't been triggered within the last ~1 minute)
		active_warnings[warning_code] = 1				--Set warning code to active
		playTone(TONE_FREQ, TONE_LEN, MUTE_LEN, PLAY_NOW, TONE_INC)		--Play tone
		t_last_tone = getTime()								
	elseif (getTime() - t_last_tone) >= WARN_TONE_DELAY then	--If warning is active and it has been WARN_TONE_DELAY since the last tone
		playTone(TONE_FREQ, TONE_LEN, MUTE_LEN, PLAY_NOW, TONE_INC)		--Play tone
		t_last_tone = getTime()
	end
end

--Displays message corresponding to "state" in the table position given by "pos": pos = 1-4
--Table has 2 columns: column one has a status flag (X for error, ! for warning, -> for info) followed by a 3 digit error code
--Column 2 has the corresponding message found in STATE_LOOKUP
local function write_state_message(state_code, pos)
	--position of display text
	local CODE_LEFT = LEFT_SIDE+12
	local FLAG_LEFT = LEFT_SIDE+4
	local MSG_LEFT = LEFT_SIDE+31
	local TOP = 10*pos + 13				--TOP changes depending on pos
	local flag = "X"							--Default status is Error
	local msg = STATE_LOOKUP[state_code]
	
	--Catch invalid input. If state_code is not in the lookup table, display error
	if msg == nil then
		msg = "MSG NOT FOUND"
	end
	
	--Check whether message is error (X), warning (!), or info(~) (~ displays as -> in this font)
	--State codes 1-199 = info, 200-399 = warning, 400+ = error
	if state_code <= 199 then flag = "~"
	elseif state_code <= 399 then 
		flag = "!" 
		FLAG_LEFT = LEFT_SIDE+5 --center ! which takes up fewer horizontal pixels
		warning_tone(state_code)  --play tones for warnings
	end
	
	--clear active warnings list if no tone has occurred in WARN_TONE_DELAY+1 second
	if (next(active_warnings) ~= nil) and ((getTime() - t_last_tone) >= WARN_TONE_DELAY+100)  then
		active_warnings = {}
	end
	
	--Display nothing if code is zero, otherwise pad zeros for 1 or 2 digit messages
	if state_code == 0 then 
		flag = " "
		msg = " "
		state_code = " "
	elseif state_code < 10 then state_code = "00"..state_code
	elseif state_code < 100 then state_code = "0"..state_code end
	
	lcd.drawText(FLAG_LEFT,TOP,flag,SMLSIZE)
	lcd.drawText(CODE_LEFT,TOP,state_code,SMLSIZE)
	lcd.drawText(MSG_LEFT,TOP,msg,SMLSIZE)
end

--Main function
local function run(event)
   lcd.clear()
   --Draw Agility Logo
   lcd.drawPixmap(8,8,"/scripts/bmp/icon.bmp")

   --read values from sensors
   batt = get_tel_val("batt")
   msg1 = get_tel_val("msg1")
   msg2 = get_tel_val("msg2")
   msg3 = get_tel_val("msg3")
   msg4 = get_tel_val("msg4")
   rec_active = get_tel_val("RSSI") --Signal strength to check connection to receiver
   
   --If receiver connection is inactive, display waiting for cassie loading screen
	if rec_active == 0 then
		lcd.drawText(LEFT_SIDE+35,15,"WAITING FOR",MIDSIZE)
		--Time%100 wraps around after 1 second, to display blinking elipses
		if (getTime()%100) <= 25 then
			loading_msg = "CASSIE"
		elseif (getTime()%100) <= 50 then
			loading_msg = "CASSIE."
		elseif (getTime()%100) <= 75 then
			loading_msg = "CASSIE.."
		elseif (getTime()%100) <= 100 then
			loading_msg = "CASSIE..."
		end
		lcd.drawText(LEFT_SIDE+50,35,loading_msg,MIDSIZE)
	--If receiver is active but all sensors report 0 values, display connection active, waiting for data loading screen
	elseif (batt+msg1+msg2+msg3+msg4) == 0 then
		lcd.drawText(LEFT_SIDE+10,5,"CASSIE CONNECTED!",MIDSIZE)
		lcd.drawText(LEFT_SIDE+35,25,"WAITING FOR",MIDSIZE)
		if (getTime()%100) <= 25 then
			loading_msg = "DATA"
		elseif (getTime()%100) <= 50 then
			loading_msg = "DATA."
		elseif (getTime()%100) <= 75 then
			loading_msg = "DATA.."
		elseif (getTime()%100) <= 100 then
			loading_msg = "DATA..."
		end
		lcd.drawText(LEFT_SIDE+58,45,loading_msg,MIDSIZE)
	
	--if receiver is active and sensor data are non-zero, display data
	else
	   --write messages to screen
	   write_state_message(msg1,1)
	   write_state_message(msg2,2)
	   write_state_message(msg3,3)
	   write_state_message(msg4,4)
	   
	   --small text: 5px width per character, 7px height (ish, not uniform width)
		draw_battery_percent(LEFT_SIDE+2,2,batt)
		lcd.drawGauge(LEFT_SIDE + 30, 2, RIGHT_SIDE-LEFT_SIDE-30, 8, batt, 100)
		
		--draw table for status messages
		lcd.drawText(LEFT_SIDE+5,13,"CODE",SMLSIZE)							
		lcd.drawText(LEFT_SIDE+65,13,"MESSAGE",SMLSIZE)						--column labels
		lcd.drawRectangle(LEFT_SIDE, 21,RIGHT_SIDE-LEFT_SIDE,41)			--outer box
		lcd.drawLine(LEFT_SIDE+1,31,RIGHT_SIDE-2,31,SOLID,FORCE)		--divide row 1 and 2
		lcd.drawLine(LEFT_SIDE+1,41,RIGHT_SIDE-2,41,SOLID,FORCE)		--divide row 2 and 3
		lcd.drawLine(LEFT_SIDE+1,51,RIGHT_SIDE-2,51,SOLID,FORCE)		--divide row 3 and 4
		lcd.drawLine(LEFT_SIDE+29,22,LEFT_SIDE+29,60,SOLID,FORCE)		--divide columns 1 and 2
	end
		
end

return { run = run, init=init_telem }
