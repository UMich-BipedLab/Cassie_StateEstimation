--Constants
local NON_REPEAT = 16
local REPEAT_ONE = 17
local REPEAT_TWO = 18
local REPEAT_THREE = 19
local REPEAT_FOUR = 20
local LINES_PER_SCREEN = 3		--4 lines: but starts from 0
--Global variables
local message = ""
local messageReceived = 0
local previousBytes = 0
local printAnchor = 20
local firstLetter = 0
local secondLetter = 0
local thirdLetter = 0
local fourthLetter = 0
local lineOne = ""
local lineTwo = ""
local lineThree = ""
local lineFour = ""
--test variables
local alternate = 0

local function drawString(anchor)
	if messageReceived < 4 then
		lcd.drawText(10, 10, lineOne, 0)
		lcd.drawText(10, 20, lineTwo, 0)
		lcd.drawText(10, 30, lineThree, 0)
		lcd.drawText(10, 40, lineFour, 0)
	else
		if anchor == 0 then
			lcd.drawText(10, 10, lineTwo, 0)
			lcd.drawText(10, 20, lineThree, 0)
			lcd.drawText(10, 30, lineFour, 0)
			lcd.drawText(10, 40, lineOne, 0)
		elseif anchor == 1 then
			lcd.drawText(10, 20, lineThree, 0)
			lcd.drawText(10, 30, lineFour, 0)
			lcd.drawText(10, 40, lineOne, 0)
			lcd.drawText(10, 10, lineTwo, 0)
		elseif anchor == 2 then
			lcd.drawText(10, 30, lineFour, 0)
			lcd.drawText(10, 40, lineOne, 0)
			lcd.drawText(10, 10, lineTwo, 0)
			lcd.drawText(10, 20, lineThree, 0)
		elseif anchor == 3 then
			lcd.drawText(10, 40, lineOne, 0)
			lcd.drawText(10, 10, lineTwo, 0)
			lcd.drawText(10, 20, lineThree, 0)
			lcd.drawText(10, 30, lineFour, 0)
		end
	end
end

local function scrolling()
	local anchor = messageReceived-LINES_PER_SCREEN*(math.floor(messageReceived/LINES_PER_SCREEN))

	if anchor == 0 then
		lineOne = string.rep(message, 0)
		drawString(0)
	elseif anchor == 1 then
		lineTwo = string.rep(message, 0)
		drawString(1)
	elseif anchor == 2 then
		lineThree = string.rep(message, 0)
		drawString(2)
	elseif anchor == 3 then
		lineFour = string.rep(message, 0)
		drawString(3)
	end
end	

local function run(event)
	--local rpm = getValue(getFieldInfo('RPM')['id'])
	if alternate == 0 then
		rpm = 1633837837
		alternate = 1
	elseif alternate == 1 then
		rpm = 3781321485
		alternate = 2
	else
		rpm = 1094861581
		alternate = 0
	end
	lcd.drawText(20, 10, "Multiple Bytes Test", 0)
	lcd.drawNumber(180, 10, rpm, 0)
	
	if rpm ~= previousBytes then
		previousBytes = rpm
		--Message decoding
		--first byte = math.floor(rpm / 256^3)
		--rpm = rpm - first byte * 256^3
		--second byte = math.floor(rpm / 256^2)
		--rpm = rpm - second byte * 256^2
		--third byte = math.floor(rpm / 256)
		--rpm = rpm - third byte * 256
		--fourth byte = rpm
		--if the first byte is bigger or equal to 128, change the fisrt bit to 0
		--otherwise, do nothing
		firstLetter = math.floor(rpm / math.pow(256, 3))
		rpm = rpm - firstLetter * math.pow(256, 3)
		if(firstLetter >= 128) then
			firstLetter = firstLetter - 128
		end
		secondLetter = math.floor(rpm / math.pow(256, 2))
		rpm = rpm - secondLetter * math.pow(256, 2)
		thirdLetter = math.floor(rpm / 256)
		rpm = rpm - thirdLetter * 256
		fourthLetter = rpm
		--decoding finished
		-------------------------------------------
		--first byte test
		if firstLetter == 13 then	--carriage return
			--lcd.drawText(10, printAnchor, message, 0)
			scrolling()
			message = ""			--clear buffer
			mesageReceived = messageReceived + 1			
			--printAnchor = printAnchor + 10
			--if printAnchor >= 60 then	--out of screen, wrap around
			--	printAnchor = 20
			--end
		else
			message = message..string.char(firstLetter)
		end
		
		--second byte test
		if secondLetter == 13 then	--carriage return
			--lcd.drawText(10, printAnchor, message, 0)
			scrolling()
			message = ""
			mesageReceived = messageReceived + 1
			--printAnchor = printAnchor + 10
			--if printAnchor >= 60 then	--out of screen, wrap around
			--	printAnchor = 20
			--end
		else
			message = message..string.char(secondLetter)
		end
		
		--third byte test
		if thirdLetter == 13 then	--carriage return
			--lcd.drawText(10, printAnchor, message, 0)
			scrolling()
			message = ""
			mesageReceived = messageReceived + 1
			--printAnchor = printAnchor + 10
			--if printAnchor >= 60 then	--out of screen, wrap around
			--	printAnchor = 20
			--end
		else
			message = message..string.char(thirdLetter)
		end
		
		--fourth byte test
		if fourthLetter == 13 then	--carriage return
			--lcd.drawText(10, printAnchor, message, 0)
			scrolling()
			message = ""
			mesageReceived = messageReceived + 1
			--printAnchor = printAnchor + 10
			--if printAnchor >= 60 then	--out of screen, wrap around
			--	printAnchor = 20
			--end
		else
			message = message..string.char(fourthLetter)
		end	
	end
end

return {run=run}